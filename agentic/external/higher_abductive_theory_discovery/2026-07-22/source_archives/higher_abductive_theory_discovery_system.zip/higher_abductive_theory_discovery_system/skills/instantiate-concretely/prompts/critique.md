Audit the proposed `instantiate-concretely` result for missing sources, scope erasure, authority overreach, hidden conjectures, incomplete obligations, and policy-budget violations.
