Apply `propose-theory-morphism` to the supplied JSON. Follow SKILL.md in order and return only a schema-valid SkillResult.
