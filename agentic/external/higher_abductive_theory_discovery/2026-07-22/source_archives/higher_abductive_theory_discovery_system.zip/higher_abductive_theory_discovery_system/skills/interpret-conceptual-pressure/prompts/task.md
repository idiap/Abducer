Apply `interpret-conceptual-pressure` to the supplied JSON. Follow SKILL.md in order and return only a schema-valid SkillResult.
